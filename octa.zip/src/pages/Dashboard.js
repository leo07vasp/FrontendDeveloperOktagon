import React from "react";

const Dashboard = () => {
  return <h1>Welcome</h1>;
};

export default Dashboard;
